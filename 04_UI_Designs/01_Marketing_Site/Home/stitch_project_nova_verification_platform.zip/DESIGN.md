---
name: Project Nova Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#d2daeb'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#e0e9f9'
  surface-container-highest: '#dae3f3'
  on-surface: '#131c28'
  on-surface-variant: '#434652'
  inverse-surface: '#28313d'
  inverse-on-surface: '#eaf1ff'
  outline: '#737784'
  outline-variant: '#c3c6d4'
  surface-tint: '#285ab9'
  primary: '#00317b'
  on-primary: '#ffffff'
  primary-container: '#0747a6'
  on-primary-container: '#a3bcff'
  inverse-primary: '#b1c6ff'
  secondary: '#4f5f7b'
  on-secondary: '#ffffff'
  secondary-container: '#cdddff'
  on-secondary-container: '#51617e'
  tertiary: '#003b48'
  on-tertiary: '#ffffff'
  tertiary-container: '#005464'
  on-tertiary-container: '#3acdef'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b1c6ff'
  on-primary-fixed: '#001946'
  on-primary-fixed-variant: '#00419d'
  secondary-fixed: '#d6e3ff'
  secondary-fixed-dim: '#b7c7e8'
  on-secondary-fixed: '#091c35'
  on-secondary-fixed-variant: '#374763'
  tertiary-fixed: '#afecff'
  tertiary-fixed-dim: '#48d7f9'
  on-tertiary-fixed: '#001f27'
  on-tertiary-fixed-variant: '#004e5d'
  background: '#f8f9ff'
  on-background: '#131c28'
  surface-variant: '#dae3f3'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  code-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  2xl: 64px
  gutter: 24px
  margin: 32px
  max-width: 1440px
---

## Brand & Style
The design system is engineered for high-stakes enterprise background verification, where precision and trust are paramount. The aesthetic is rooted in **Modern Corporate Minimalism**, heavily influenced by high-end financial platforms. It prioritizes clarity over decoration, using ample whitespace and a rigorous grid to signal stability and compliance.

The target audience consists of HR directors, legal compliance officers, and operations managers who require a tool that feels authoritative and efficient. The UI evokes a sense of "quiet intelligence"—it stays out of the way of the data while providing a premium, polished experience through micro-interactions and perfect alignment.

## Colors
The palette is centered around **Deep Professional Blue**, a color that communicates institutional trust and security. 

- **Primary:** Used for main actions, active states, and brand presence.
- **Secondary:** A slate blue-gray used for sub-navigation and secondary text to reduce visual fatigue.
- **Surface & Background:** The system uses a "Pure White" base with "Atlassian-style" light gray accents (#F4F5F7) to create distinct sections without the need for heavy borders.
- **Status Colors:** Standardized semantic colors for verification results (Clear, Flagged, Pending). Use high-saturation but professional tones to ensure they are legible against white backgrounds.

## Typography
**Inter** is utilized across all levels to maintain a systematic, utilitarian feel. The hierarchy is strictly enforced:
- **Headlines:** Use a tighter letter-spacing and semi-bold weights to appear grounded.
- **Body Text:** Optimized for long-form data reading with a 1.5x line-height ratio.
- **Labels:** Used for table headers and small captions, often in all-caps with slight tracking for professional categorization.
- **Data Mono:** For reference numbers or IDs, JetBrains Mono is permitted in small doses to signify technical accuracy.

## Layout & Spacing
The layout follows a **Fixed-Fluid Hybrid** model. Content is contained within a 1440px max-width container on desktop, centered with generous margins.

- **The 8px Grid:** All spacing between elements must be a multiple of 8px (or 4px for tight UI components).
- **Desktop:** 12-column grid, 24px gutters.
- **Tablet:** 8-column grid, 16px gutters.
- **Mobile:** 4-column grid, 16px gutters. 
- **Premium Padding:** Use `xl` (40px) or `2xl` (64px) padding for section headers and major card groupings to create the Stripe-inspired "airy" feel.

## Elevation & Depth
Depth is created through **Tonal Layering** and **Subtle Ambient Shadows**. 
- **Level 0 (Background):** #FFFFFF.
- **Level 1 (Sections):** #F4F5F7 background with no shadow.
- **Level 2 (Cards/Modals):** #FFFFFF background with a 1px border (#E1E4E8) and a soft, multi-layered shadow: `0px 1px 3px rgba(0,0,0,0.04), 0px 4px 12px rgba(0,0,0,0.08)`.
- **Interaction:** On hover, cards may increase their shadow slightly but should never appear to "float" excessively high. The goal is a tactile, paper-on-desk feel.

## Shapes
The design system uses a **Soft (Level 1)** roundedness profile. This 4px/8px radius balance provides a modern feel while remaining professional and "serious" enough for enterprise compliance software.
- **Small Components (Buttons, Inputs):** 4px radius.
- **Large Components (Cards, Modals):** 8px radius.
- **Full Rounding:** Only used for status badges/tags to distinguish them from interactive buttons.

## Components
### Buttons
- **Primary:** Solid #0747A6 with white text. No gradients.
- **Secondary:** White background, 1px border (#DFE1E6), dark text (#42526E).
- **Sizing:** 36px height for standard, 44px for large forms.

### Data Tables
- **Header:** Light gray background (#F4F5F7), uppercase 12px semi-bold labels.
- **Rows:** 52px height, 1px bottom border (#EBECF0). No zebra striping; use hover highlights instead.

### Status Badges
- Small, rounded-pill shapes.
- High-contrast text on very low-opacity backgrounds (e.g., Success: Green text on 10% Green background).

### Input Fields
- 1px border (#DFE1E6). On focus, border changes to Primary Blue with a 2px soft blue glow (outline).
- Labels are always positioned above the input, never as placeholders only.

### Professional Cards
- Used for applicant summaries. 24px internal padding. 1px border #E1E4E8. Use light gray headers (#F4F5F7) to separate metadata from the body.